from . import randompython as rnd
def randomx(length, chars):
 choice = rnd.choice
 res = ""
 for i in range(length):
  res += choice(chars)
 return res
"""#randompython.py
import time as tm
import os

def sleep(secs):
    tm.sleep(secs)
def choice(choices):
    seed = int(ord(os.urandom(1).decode("ISO-8859-1")) % len(choices))
    return choices[seed]"""
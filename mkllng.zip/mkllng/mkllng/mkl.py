# mkl.py
import re
import sys 
import os
sys.path.append(os.getcwd())
from randomx import randomx as rnd
if r"\\"[1] in __file__:
  os.chdir(r"\\"[1].join(__file__.split(r"\\"[1])[0:-1]))
elif "/" in __file__:
  os.chdir("/".join((__file__.split("/")[0:-1])))
path = os.getcwd()
def mkl(code, line, varis:dict = {}):
    global path
    import os
    varis["_file_"] = __file__
    varis["_path_"] = path
    def is_num(num):
        try:
            float(num)
            return True
        except ValueError:
            return False            
    def mkp(length=20, words="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890"):
        result = rnd.randomx(length, words)
        return result

    def f(text:str, line):
        res = ""
        text = str(text).replace(r"\s", " ").replace(r"\l", "\n")
        for o in text.split():
            if o.startswith("&*"):
                var_name = o[2:]
                if var_name in varis:
                    res += f"{varis[var_name]} "
                else:
                   res += o + " "
            else:
                res += o + " "  
        return res.strip()
    def sq(num, line):
        patr = re.match(r"\s*([0-9\.]+)\s*,\s*(\w+)\s*", str(num).strip())
        if patr:
          varname = patr.group(2)
          numx = f(patr.group(1), line)
          if is_num(numx):
            result = float(numx) ** 0.5
            varis[varname] = result
          else:
            print(f"ValueError: Cannot calculate square root for '{numx}' line: ({line})")
        else:
            print(rf"SyntaxError: Expected syntax: number, variable_name line: ({line})")
            
    def cr(command, line):
        import os
        try:
          patr = re.match(r"\s*[\"'](.*)[\"']\s*", str(command))
          if patr:
           x = input("Warning: To run Python code, you must confirm. Do you want to create a temporary Python file? (y/n)")
           if x.lower() == "y":
             try:
               os.mkdir("__mklcache__")
             except FileExistsError:
                pass
             with open(r"__mklcache__\main.py", "w", encoding="utf-8") as f:
               x = ""
               print(x)
               for i in varis:
                  if is_num(varis[i]):
                     x += rf"{i} = {varis[i]}" + "\n"
                  else:
                     x += rf"{i} = r'{varis[i]}'" + "\n"
               tempp = os.environ.get("TEMP")
               f.write(x + patr.group(1).replace("~", ";").replace(r"\l", "\n").replace(r"\s", " "))
             os.system(r"python __mklcache__\main.py")
             os.remove(r"__mklcache__\main.py")
           else:
              print(rf"SyntaxError: Expected syntax: 'Python code here' (line: {line})")
        except Exception as e:
            print(f"RunTimeError: PyError.{e.__class__.__name__}: {" ".join(e.args)} (line: {line})")
        # الان يمكن مثلا كتابة e
    libs = {"math":{"square":sq}, "pycode":{"command_run":cr}}
    
    for i in re.split(r"[\n;]", code):
        patr1 = re.match(r"\s*print\s*\(\s*[\"'](.*)[\"']\)\s*", i)
        patr2 = re.match(r"\s*(\w+)\s*=\s*random \s*(\d+)\s*[\"'](.*)[\"']\s*", i)
        patr3 = re.match(r"\s*(\w+)\s*=\s*[\"'](.*)[\"']\s*", i)
        patr4 = re.match(r"\s*wait\s*\(\s*(\d+)\s*\)\s*", i)
        patr5 = re.match(r"\s*view \s*vars\s*", i)
        patr6 = re.match(r"\s*exit\s*\(\s*\)\s*",i)
        patr7 = re.match(r"\s*help\s*\(\s*\)\s*", i)
        patr8 = re.match(r"\s*copyright\s*\(\s*\)\s*", i)
        patr9 = re.match(r"\s*input\s*\(\s*[\"'](.*)[\"']\s*,\s*(\w+)\s*\)\s*", i) 
        patr10 = re.match(r"\s*(\w+)\s*=\s*(\w+)\s*", i)
        patr11 = re.match(r"\s*len\s*\(\s*[\"'](.*)[\"']\s*,\s*(\w+)\)\s*", i)
        patr12 = re.match(r"\s*#(.*)", i)
        patr13 = re.match(r"\s*math\s*(\w+)\s*=\s*(.*)\s*", i)
        patr14 = re.match(r"\s*cls\s*\(\s*\)\s*", i)
        patr15 = re.match(r"\s*\s*replace\s*\(\s*[\"'](.*)[\"']\s*,\s*[\"'](.*)[\"']\s*,\s*[\"'](.*)[\"']\s*,\s*(\w+)\s*\)\s*", i)
        patr16 = re.match(r"\s*concat\s*\(\s*[\"'](.*)[\"']\s*,\s*(\w+)\s*\)\s*", i)
        patr17 = re.match(r"\s*str \s*(\w+)\s*=\s*(\w+)\s*\+\s*(\w+)\s+bettwen\s*=\s*[\"'](.*)[\"']", i)
        patr19 = re.match(r"\s*exec\s*\([\"'](.*)[\"']\)\s*", i)
        patr20 = re.match(r"\s*import\s+(\w+)\s*\.\s*(\w+)\s*\((.*)\)\s*", i)
        patr21 = re.match(r"\s*write\s+(\w+)\s+to\s+(\w+)\.(\w+)\s*", i)
        patr22 = re.match(r"\s*read\s+to\s+(\w+)\s*", i)
        patr23 = re.match(r"\s*cd\s+(.*)", i)
        
        if patr1:
            x = patr1.group(1)
            print(f(x, line))
        elif patr2:
          try:
            word = patr2.group(3)
            length = int(f(patr2.group(2), line))
            name = patr2.group(1)
            varis[name] = mkp(int(f(length, line)), f(word, line))
          except ValueError as v:
              print(f"ValueError: Length must be an integer (line: {line})")
        elif patr3:
            varis[patr3.group(1)] = f(patr3.group(2), line)
        elif patr4:
          try:
            rnd.sleep(int(patr4.group(1))) 
          except ValueError:
              print(f"ValueError: Wait time must be an integer (line: {line})")
        elif patr5:
            print(varis)
        elif patr6:
            print()
            sys.exit(0)
        elif patr7:
           print("print: Prints a message, set: Sets a random variable using custom characters, name = value: Assigns a value to a variable, wait(time): Pauses execution for a set time (in seconds), view vars: Displays all current variables, exit(): Exits the program, input: Gets user input and saves it to a variable, help: Displays this command list, copyright: Shows the language copyright, math: Executes complex mathematical calculations, cls: Clears the terminal screen, concat: Concatenates variables into a new string, replace: Replaces a character or text within a string, import: Imports functions from embedded libraries (e.g., math.square).")
        elif patr8:
            print("MKL language copyright 2025\nPython language copyright 2025")
        elif patr9:
            varis[patr9.group(2)] = input(f(patr9.group(1), line))
        elif patr10:
                varname = patr10.group(1)
                vals = patr10.group(2)
                if vals in varis:
                 varis[varname] = varis[val]
                else:
                    try:
                       val = float(vals)
                       varis[varname] = int(val) if val == int(val) else val
                    except ValueError:
                       print(f"ValueError: '{varis[patr10.group(2)]}' is not a number (line: {line})")
        elif patr11:
          try:
            varis[patr11.group(2)] = str(len(f(patr11.group(1), line)))
          except ValueError:
              print(f"ValueError: Cannot calculate length of a non-literal value (line: {line})")
        elif patr12:
            pass
        elif patr13:
         try:
            x = f(patr13.group(2), line)
            if re.fullmatch(r"[0-9\.\+\-\*\/\%\(\)\^\&\*\s]+", x):
                try:
                    varis[patr13.group(1)] = eval(x.replace("^", "**"), {"__builins__":{}}, {})
                except Exception as e:
                    print(f"RunTimeError: {" ".join(e.args)} (line: {line})")
            else:
                print(f"SyntaxError: Disallowed characters detected (line: {line})")
         except Exception as e:
            print(f"RunTimeError: {" ".join(e.args)} (line: {line})")
        elif patr14:
            import os
            os.system("cls" if "nt" in os.name else "clear")
        elif patr15:
            varis[patr15.group(4)] = f(patr15.group(1), line).replace(f(patr15.group(2), line), f(patr15.group(3), line))
        elif patr16:
            varis[patr16.group(2)] = f(patr16.group(1), line)
        elif patr17:
            nvn = patr17.group(1)
            vn1 = patr17.group(2)
            vn2 = patr17.group(3)
            bet = f(patr17.group(4), line)
            if not vn1 in varis:
              print(f"NameError: Variable '{patr17.group(2)}' not found (line: {line})")
              line += 1
              continue
            if not vn2 in varis:
              print(f"NameError: Variable '{patr17.group(3)}' not found (line: {line})")
              line += 1
              continue
            varis[nvn] = str(varis[vn1]) + str(bet) + str(varis[vn2])
        elif patr19:
            mkl(patr19.group(1).replace("~", ";").replace("$*", "&*"))
        elif patr20:
             libname = patr20.group(1)
             funcname = patr20.group(2)
             args = patr20.group(3)
             if libname in libs:
                 if funcname in libs[libname]:
                    func = libs[libname]
                    if callable(func[funcname]):
                     try:
                       func[funcname](args, line)
                     except TypeError:
                      try:
                        func[funcname]()
                      except TypeError:
                         print(f"AgrumentsValueError: the agruments of thes function it must be uper than length args")
                    else:
                        print("error")
                        line += 1;continue  
                 else:
                     print(f"SyntaxError: Cannot call '{patr20.group(2)}' (line: {line})")
                     line += 1
                     continue
             else:
                 try:
                    with open(libname + ".mkl", "r", encoding="utf-8") as fx:
                       mkl(fx.read().strip(), line, varis)
                 except FileNotFoundError:
                     print(f"SyntaxError: Cannot call '{patr20.group(2)}' (line: {line})")
                     line += 1
                     continue
        elif patr21:
            file_name = path + "/" + patr21.group(2) + "." + patr21.group(3)
            with open(file_name, "w", encoding="utf-8") as fx:
                    fx.write(f(patr21.group(1), line))
        elif patr22:
            file_name = path
            var_name = f(patr22.group(1), line)
            if os.path.exists(file_name):
                try:
                    with open(file_name, "r", encoding="utf-8") as fx:
                        varis[var_name] = fx.read()
                except Exception as e:
                    print(f"RunTimeError: {" ".join(e.args)} (line: {line})")
            else:
                print(f"FileNotFoundError: file '{file_name}' is not found (line: {line})")
        elif patr23:
            path = patr23.group(1)
        elif i == "" or i.isspace() or not i:
            line += 1
            continue
        else:
            print(f"SyntaxError: Unknown command or syntax error (line: {line})")
            line += 1
            continue
        line += 1
varibles = {}
line = 1
if __name__ == "__main__":
 if len(sys.argv) >= 2:
  for l in sys.argv[1:]:
   if l.endswith(".mkl"):
        try:
            with open(l, "r", encoding="utf-8") as f:
                mkl(f.read(), 1, varibles)
        except FileNotFoundError:
            print(f"FileError: File '{l}' is not found.")
            break
 else:
    print("MKL language copyright 2025\nPython language copyright 2025")
    while True: 
      os.chdir(path)
      try:
        mkl(input(">>>"), line, varibles)
      except (EOFError, KeyboardInterrupt):
          print()
          break # الملف الاول: 263 سطر
"""#randomx
from . import randompython as rnd
def randomx(length, chars):
 choice = rnd.choice
 res = ""
 for i in range(length):
  res += choice(chars)
 return res
""" #الملف الثاني 8 اسطر
"""#randompython.py
import time as tm
import os

def sleep(secs):
    tm.sleep(secs)
def choice(choices):
    seed = int(ord(os.urandom(1).decode("ISO-8859-1")) % len(choices))
    return choices[seed]""" # الملف الثالث 7 اسطر بدون احتساب السطر الفارغ
#هاكذا كلهم معا 280 لكن مع احتساب السطر الفارغ 281
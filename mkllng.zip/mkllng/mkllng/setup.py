import sys
from cx_Freeze import setup, Executable
sys.path.append(r"C:\Users\win10\Desktop\mkllng\randomx")
# الإعدادات الأساسية
build_exe_options = {
    "packages": ["randomx"], # أضف أسماء المكتبات المستخدمة هنا (مثل pandas, requests)
    "excludes": [],     # استبعاد مكتبات معينة لتقليل الحجم
    "include_files": [] # أضف ملفات إضافية مثل الصور أو قواعد البيانات هنا
}

# لتجنب ظهور نافذة الـ Console في برامج الواجهات الرسومية (GUI)
base = None
if sys.platform == "win32":
    base = "Win32GUI" 
elif sys.platform == "win64":
    base = "Win64GUI" 

setup(
    name = "mkllng",
    version = "1.0",
    description = "وصف للبرنامج",
    options = {"build_exe": build_exe_options},
    executables = [Executable("mkl.py", base=base, icon="icon.ico")] # استبدل main.py باسم ملفك
)
